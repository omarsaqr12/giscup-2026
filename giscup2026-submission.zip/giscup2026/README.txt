SIGSPATIAL 2026 GIS Cup -- antenna placement
============================================

CONTENTS
  results.txt   the nine-block results file (one block = 3 lines:
                "(tau, k)"; the k antenna coordinates; the claimed building ids)
  source/       complete source, tests and tooling

BUILD
  cd source && make portable

  Requires a C++17 compiler with OpenMP. No third-party libraries: the GeoJSON
  reader, geometry kernel and spatial index are all in-tree. `make portable`
  omits -march=native so the binary is not tuned to our machine.

RUN
  ./giscup solve --data <dataset>.geojson \
      --params <competition-parameters> \
      --radius <R> --verify-radius <V> \
      --lns-sec <seconds> --swap 400 \
      --archive-add --out results.txt

  Radii are re-derived per dataset rather than assumed:
      ./giscup tune --data <dataset>.geojson --tau <t> --k <k>

  One-command readiness check on an unseen dataset:
      bash tools/runday.sh <dataset>.geojson <competition-parameters.txt>

VERIFY
  ./giscup verify --data <dataset>.geojson --out results.txt
  python3 tests/conformance.py results.txt 9

  The first re-derives every claim with an exact, uncapped visibility sweep and
  reports false claims, unclaimed-but-serviceable buildings and unknown ids. The
  second checks the file against the official evaluator's parser rules.

METHOD
  Visible boundary arcs are computed exactly by rotational plane sweep -- no
  boundary sampling, so coverage ratios carry no discretisation error. Antennas
  are placed at polygon vertices, where a single antenna covers both incident
  edges outright. Selection optimises a per-building potential (tuned per
  sub-problem) under a target-set restriction, followed by 2-exchange and
  large-neighbourhood polish. See source/FINDINGS.md for the measured
  justification of each choice, including the approaches that were tried and
  rejected.

AI DISCLOSURE
  This entry was developed with AI assistance (Claude). Every reported number is
  reproducible from the commands recorded in source/FINDINGS.md.
